#!/usr/bin/env python3
"""
Generate the body PDF for the Manual de Usuario - Sistema de Control de Asistencia
NOM-037-STPS-2023 compliance manual using ReportLab.
"""

import hashlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, CondPageBreak, HRFlowable
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily

# ── Page dimensions ──
PAGE_W, PAGE_H = A4
LEFT_MARGIN = 1.0 * inch
RIGHT_MARGIN = 1.0 * inch
TOP_MARGIN = 0.9 * inch
BOTTOM_MARGIN = 0.9 * inch
CONTENT_W = PAGE_W - LEFT_MARGIN - RIGHT_MARGIN

# ── Color Palette (auto-generated) ──
ACCENT       = colors.HexColor('#4e2abc')
TEXT_PRIMARY  = colors.HexColor('#1e2022')
TEXT_MUTED    = colors.HexColor('#81868d')
BG_SURFACE   = colors.HexColor('#e1e3e6')
BG_PAGE      = colors.HexColor('#edeff0')

TABLE_HEADER_COLOR = ACCENT
TABLE_HEADER_TEXT  = colors.white
TABLE_ROW_EVEN     = colors.white
TABLE_ROW_ODD      = BG_SURFACE

# ── Font Registration ──
pdfmetrics.registerFont(TTFont('Carlito', '/usr/share/fonts/truetype/english/Carlito-Regular.ttf'))
pdfmetrics.registerFont(TTFont('Carlito-Bold', '/usr/share/fonts/truetype/english/Carlito-Bold.ttf'))
pdfmetrics.registerFont(TTFont('Carlito-Italic', '/usr/share/fonts/truetype/english/Carlito-Italic.ttf'))
pdfmetrics.registerFont(TTFont('Carlito-BoldItalic', '/usr/share/fonts/truetype/english/Carlito-BoldItalic.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSerif', '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSerif-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSansMono', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))

registerFontFamily('Carlito', normal='Carlito', bold='Carlito-Bold', italic='Carlito-Italic', boldItalic='Carlito-BoldItalic')
registerFontFamily('DejaVuSerif', normal='DejaVuSerif', bold='DejaVuSerif-Bold')
registerFontFamily('DejaVuSans', normal='DejaVuSans', bold='DejaVuSans-Bold')

# ── Styles ──
H1_STYLE = ParagraphStyle(
    name='H1', fontName='Carlito-Bold', fontSize=22, leading=28,
    textColor=ACCENT, spaceBefore=24, spaceAfter=12, alignment=TA_LEFT
)
H2_STYLE = ParagraphStyle(
    name='H2', fontName='Carlito-Bold', fontSize=15, leading=21,
    textColor=TEXT_PRIMARY, spaceBefore=16, spaceAfter=8, alignment=TA_LEFT
)
H3_STYLE = ParagraphStyle(
    name='H3', fontName='Carlito-Bold', fontSize=12, leading=17,
    textColor=ACCENT, spaceBefore=12, spaceAfter=6, alignment=TA_LEFT
)
BODY_STYLE = ParagraphStyle(
    name='Body', fontName='DejaVuSerif', fontSize=10.5, leading=16,
    textColor=TEXT_PRIMARY, spaceBefore=0, spaceAfter=8, alignment=TA_JUSTIFY,
    firstLineIndent=0
)
BODY_INDENT = ParagraphStyle(
    name='BodyIndent', fontName='DejaVuSerif', fontSize=10.5, leading=16,
    textColor=TEXT_PRIMARY, spaceBefore=0, spaceAfter=6, alignment=TA_JUSTIFY,
    leftIndent=20
)
BULLET_STYLE = ParagraphStyle(
    name='Bullet', fontName='DejaVuSerif', fontSize=10.5, leading=16,
    textColor=TEXT_PRIMARY, spaceBefore=2, spaceAfter=4, alignment=TA_LEFT,
    leftIndent=28, firstLineIndent=-14, bulletIndent=14
)
BULLET_STYLE2 = ParagraphStyle(
    name='Bullet2', fontName='DejaVuSerif', fontSize=10.5, leading=16,
    textColor=TEXT_PRIMARY, spaceBefore=2, spaceAfter=4, alignment=TA_LEFT,
    leftIndent=48, firstLineIndent=-14, bulletIndent=34
)
CALLOUT_STYLE = ParagraphStyle(
    name='Callout', fontName='Carlito-Italic', fontSize=10.5, leading=16,
    textColor=ACCENT, spaceBefore=6, spaceAfter=6, alignment=TA_LEFT,
    leftIndent=24, borderWidth=0, borderPadding=0,
    borderColor=ACCENT, borderRadius=0
)
TABLE_HEADER_STYLE = ParagraphStyle(
    name='TableHeader', fontName='Carlito-Bold', fontSize=10,
    leading=14, textColor=colors.white, alignment=TA_CENTER
)
TABLE_CELL_STYLE = ParagraphStyle(
    name='TableCell', fontName='DejaVuSerif', fontSize=9.5,
    leading=14, textColor=TEXT_PRIMARY, alignment=TA_LEFT
)
TABLE_CELL_CENTER = ParagraphStyle(
    name='TableCellCenter', fontName='DejaVuSerif', fontSize=9.5,
    leading=14, textColor=TEXT_PRIMARY, alignment=TA_CENTER
)
CAPTION_STYLE = ParagraphStyle(
    name='Caption', fontName='Carlito-Italic', fontSize=9,
    leading=13, textColor=TEXT_MUTED, alignment=TA_CENTER,
    spaceBefore=4, spaceAfter=12
)
FOOTER_STYLE = ParagraphStyle(
    name='Footer', fontName='DejaVuSerif', fontSize=8,
    leading=11, textColor=TEXT_MUTED, alignment=TA_CENTER
)
TOC_H1 = ParagraphStyle(
    name='TOC1', fontName='Carlito-Bold', fontSize=13, leading=20,
    leftIndent=20, textColor=TEXT_PRIMARY
)
TOC_H2 = ParagraphStyle(
    name='TOC2', fontName='DejaVuSerif', fontSize=11, leading=18,
    leftIndent=40, textColor=TEXT_PRIMARY
)

# ── TocDocTemplate ──
class TocDocTemplate(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, 'bookmark_name'):
            level = getattr(flowable, 'bookmark_level', 0)
            text = getattr(flowable, 'bookmark_text', '')
            key = getattr(flowable, 'bookmark_key', '')
            self.notify('TOCEntry', (level, text, self.page, key))

H1_ORPHAN_THRESHOLD = (PAGE_H - TOP_MARGIN - BOTTOM_MARGIN) * 0.15

def add_heading(text, style, level=0):
    key = 'h_%s' % hashlib.md5(text.encode()).hexdigest()[:8]
    p = Paragraph('<a name="%s"/>%s' % (key, text), style)
    p.bookmark_name = text
    p.bookmark_level = level
    p.bookmark_text = text
    p.bookmark_key = key
    return p

def add_major_section(text, style=H1_STYLE, level=0):
    return [
        CondPageBreak(H1_ORPHAN_THRESHOLD),
        add_heading(text, style, level),
    ]

def make_table(headers, rows, col_widths=None):
    """Create a styled table with headers and rows."""
    data = [[Paragraph('<b>%s</b>' % h, TABLE_HEADER_STYLE) for h in headers]]
    for row in rows:
        data.append([Paragraph(str(c), TABLE_CELL_STYLE) for c in row])

    if col_widths is None:
        col_widths = [CONTENT_W / len(headers)] * len(headers)
    else:
        total = sum(col_widths)
        if total < CONTENT_W * 0.85:
            scale = (CONTENT_W * 0.92) / total
            col_widths = [w * scale for w in col_widths]

    t = Table(data, colWidths=col_widths, hAlign='CENTER')
    style_cmds = [
        ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER_COLOR),
        ('TEXTCOLOR', (0, 0), (-1, 0), TABLE_HEADER_TEXT),
        ('GRID', (0, 0), (-1, -1), 0.5, TEXT_MUTED),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]
    for i in range(1, len(data)):
        bg = TABLE_ROW_EVEN if i % 2 == 1 else TABLE_ROW_ODD
        style_cmds.append(('BACKGROUND', (0, i), (-1, i), bg))
    t.setStyle(TableStyle(style_cmds))
    return t

def hr():
    return HRFlowable(width="100%", thickness=0.5, color=ACCENT, opacity=0.2, spaceBefore=6, spaceAfter=6)

def bullet(text):
    return Paragraph('<bullet>&bull;</bullet> ' + text, BULLET_STYLE)

def bullet2(text):
    return Paragraph('<bullet>-</bullet> ' + text, BULLET_STYLE2)

# ── Build Document ──
OUTPUT_PATH = '/home/z/my-project/manual-body.pdf'

doc = TocDocTemplate(
    OUTPUT_PATH,
    pagesize=A4,
    leftMargin=LEFT_MARGIN,
    rightMargin=RIGHT_MARGIN,
    topMargin=TOP_MARGIN,
    bottomMargin=BOTTOM_MARGIN,
    title='Manual de Usuario - Sistema de Control de Asistencia',
    author='Z.ai',
    creator='Z.ai',
    subject='Manual de Usuario para el Sistema de Control de Asistencia NOM-037-STPS-2023'
)

story = []

# ── Table of Contents ──
story.append(Paragraph('<b>Contenido</b>', ParagraphStyle(
    name='TOCTitle', fontName='Carlito-Bold', fontSize=22, leading=28,
    textColor=ACCENT, spaceBefore=20, spaceAfter=20, alignment=TA_LEFT
)))
toc = TableOfContents()
toc.levelStyles = [TOC_H1, TOC_H2]
story.append(toc)
story.append(PageBreak())

# ══════════════════════════════════════════════════════════════════
# 1. INTRODUCCION
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('1. Introduccion'))
story.append(Paragraph(
    'El <b>Sistema de Control de Asistencia</b> es una aplicacion web disenada para registrar, '
    'monitorear y gestionar la asistencia del personal laboral en cumplimiento con la '
    '<b>NOM-037-STPS-2023</b>, la Norma Oficial Mexicana que regula las condiciones de seguridad '
    'y salud en el trabajo para las personas trabajadoras que laboran bajo la modalidad de teletrabajo.',
    BODY_STYLE
))
story.append(Spacer(1, 8))
story.append(Paragraph(
    'Este sistema permite a las organizaciones mantener un control preciso y transparente '
    'de los registros de asistencia, garantizando la trazabilidad e inmutabilidad de los datos, '
    'requisitos fundamentales establecidos por la normativa vigente.',
    BODY_STYLE
))
story.append(Spacer(1, 8))
story.append(Paragraph('<b>Caracteristicas principales:</b>', H3_STYLE))
story.append(bullet('<b>Autenticacion dual:</b> Registro de entrada y salida mediante codigo QR dinamico y/o contrasena personal, asegurando la identidad del trabajador.'))
story.append(bullet('<b>Geolocalizacion GPS:</b> Captura obligatoria de la ubicacion del empleado al registrar asistencia, conforme a lo establecido por la NOM-037.'))
story.append(bullet('<b>Registros inmutables:</b> Todos los registros de asistencia son almacenados de forma permanente y no pueden ser alterados, garantizando la integridad de la informacion.'))
story.append(bullet('<b>Auditoria completa:</b> Toda accion dentro del sistema es registrada con fecha, hora, usuario y descripcion, creando una pista de auditoria trazable.'))
story.append(bullet('<b>Reportes exportables:</b> Generacion de reportes diarios, de horas extra y ausencias en formatos CSV y Excel, con filtros por sucursal y periodo.'))
story.append(bullet('<b>Terminal QR dinamico:</b> Codigo QR que se renueva cada 5 minutos, evitando suplantacion de identidad.'))
story.append(Spacer(1, 8))
story.append(Paragraph(
    '<b>NOM-037-STPS-2023</b> establece que los patrones deben llevar un registro de asistencia '
    'de las personas trabajadoras que realizan teletrabajo, verificando la fecha y hora de entrada '
    'y salida, asi como la realizacion de las actividades asignadas. Este sistema cumple con todos '
    'los requisitos normativos aplicables.',
    CALLOUT_STYLE
))

# ══════════════════════════════════════════════════════════════════
# 2. ACCESO AL SISTEMA
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('2. Acceso al Sistema'))
story.append(Paragraph('<b>2.1 Proceso de inicio de sesion</b>', H2_STYLE))
story.append(Paragraph(
    'Para acceder al sistema, el usuario debe dirigirse a la pagina principal e ingresar sus credenciales. '
    'El sistema ofrece dos metodos de autenticacion:',
    BODY_STYLE
))
story.append(bullet('<b>Contrasena:</b> Ingrese su correo electronico y contrasena en el formulario de inicio de sesion.'))
story.append(bullet('<b>Codigo QR:</b> Escanee su codigo QR personal desde la pestana de acceso QR en la pantalla de login.'))
story.append(Spacer(1, 8))
story.append(Paragraph('<b>2.2 Roles de usuario</b>', H2_STYLE))
story.append(Paragraph(
    'El sistema define dos roles con permisos diferenciados:',
    BODY_STYLE
))

story.append(Spacer(1, 10))
role_table = make_table(
    ['Rol', 'Permisos', 'Acceso'],
    [
        ['Administrador (ADMIN)', 'Acceso total: dashboard, empleados, asistencias, reportes, auditoria, terminal QR', 'Panel de Administracion'],
        ['Empleado (EMPLOYEE)', 'Registro de entrada/salida, historial personal, codigo QR personal', 'Panel del Empleado'],
    ],
    col_widths=[120, 220, 130]
)
story.append(role_table)
story.append(Paragraph('Tabla 1. Roles y permisos del sistema', CAPTION_STYLE))

story.append(Spacer(1, 8))
story.append(Paragraph('<b>2.3 Credenciales de demostracion</b>', H2_STYLE))
story.append(Paragraph(
    'Para fines de demostracion, el sistema incluye las siguientes credenciales preconfiguradas:',
    BODY_STYLE
))

story.append(Spacer(1, 10))
cred_table = make_table(
    ['Rol', 'Correo', 'Contrasena', 'Sucursal'],
    [
        ['Administrador', 'admin@asistencias.com', 'Admin123!', 'Matriz'],
        ['Empleado', 'mogatru@gmail.com', 'Empleado123!', 'Matriz'],
        ['Empleado', 'marlui367@gmail.com', 'Empleado123!', 'Sucursal 1'],
    ],
    col_widths=[90, 160, 100, 100]
)
story.append(cred_table)
story.append(Paragraph('Tabla 2. Credenciales de demostracion', CAPTION_STYLE))

# ══════════════════════════════════════════════════════════════════
# 3. PANEL DEL ADMINISTRADOR
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('3. Panel del Administrador'))
story.append(Paragraph(
    'El panel del administrador proporciona herramientas completas para la gestion de la asistencia laboral. '
    'Se accede al iniciar sesion con credenciales de rol ADMIN y esta compuesto por seis secciones principales.',
    BODY_STYLE
))

# 3.1 Dashboard
story.append(Paragraph('<b>3.1 Dashboard</b>', H2_STYLE))
story.append(Paragraph(
    'El dashboard presenta un resumen del dia en tiempo real con los siguientes indicadores:',
    BODY_STYLE
))
story.append(bullet('<b>Presentes:</b> Numero de empleados que registraron entrada sin retardo.'))
story.append(bullet('<b>Retardos:</b> Empleados que llegaron despues de la hora de entrada configurada, dentro del periodo de tolerancia.'))
story.append(bullet('<b>Ausentes:</b> Empleados que no registraron entrada en el dia.'))
story.append(bullet('<b>Total de empleados:</b> Cantidad total de empleados activos en el sistema.'))
story.append(Spacer(1, 6))
story.append(Paragraph(
    'El dashboard se actualiza automaticamente y permite al administrador tener una vision inmediata '
    'del estado de asistencia del personal.',
    BODY_STYLE
))

# 3.2 Empleados
story.append(Paragraph('<b>3.2 Empleados</b>', H2_STYLE))
story.append(Paragraph(
    'La seccion de empleados permite gestionar todo el personal de la organizacion:',
    BODY_STYLE
))
story.append(Paragraph('<b>Operaciones CRUD:</b>', H3_STYLE))
story.append(bullet('<b>Crear:</b> Registrar nuevos empleados con nombre, correo, puesto, sucursal y horario.'))
story.append(bullet('<b>Leer:</b> Consultar la lista completa de empleados con filtros de busqueda.'))
story.append(bullet('<b>Actualizar:</b> Modificar datos del empleado, sucursal asignada y horario laboral.'))
story.append(bullet('<b>Desactivar:</b> Inhabilitar el acceso de un empleado sin eliminar su historial.'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>Asignacion de sucursal:</b>', H3_STYLE))
story.append(Paragraph(
    'Cada empleado es asignado a una sucursal especifica. Las sucursales disponibles son:',
    BODY_STYLE
))
story.append(bullet('Matriz (oficina principal)'))
story.append(bullet('Sucursal 1'))
story.append(bullet('Sucursal 2'))
story.append(bullet('Sucursal 3'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>Horarios personalizables:</b>', H3_STYLE))
story.append(Paragraph(
    'Se pueden configurar horarios individuales para cada empleado, con entrada y salida para cada dia de lunes a sabado. '
    'Los horarios predeterminados son:',
    BODY_STYLE
))

story.append(Spacer(1, 10))
schedule_table = make_table(
    ['Dia', 'Hora de Entrada', 'Hora de Salida'],
    [
        ['Lunes a Viernes', '09:00', '18:00'],
        ['Sabado', '09:00', '14:00'],
    ],
    col_widths=[180, 140, 140]
)
story.append(schedule_table)
story.append(Paragraph('Tabla 3. Horario laboral predeterminado', CAPTION_STYLE))

story.append(Spacer(1, 6))
story.append(Paragraph('<b>Codigo QR individual:</b>', H3_STYLE))
story.append(Paragraph(
    'Cada empleado cuenta con un codigo QR personal unico para autenticacion. Este codigo se genera '
    'automaticamente al crear el empleado y puede ser regenerado desde la seccion de empleados.',
    BODY_STYLE
))

# 3.3 Asistencias
story.append(Paragraph('<b>3.3 Asistencias</b>', H2_STYLE))
story.append(Paragraph(
    'La seccion de asistencias muestra el historial completo de registros de entrada y salida del personal, '
    'con las siguientes funcionalidades:',
    BODY_STYLE
))
story.append(bullet('<b>Historial completo:</b> Visualizacion de todos los registros de asistencia.'))
story.append(bullet('<b>Filtros por periodo:</b> Seleccion de rango de fechas para consultar registros especificos.'))
story.append(bullet('<b>Informacion detallada:</b> Cada registro incluye nombre del empleado, fecha, hora de entrada, hora de salida, ubicacion GPS y estado.'))
story.append(bullet('<b>Estados de asistencia:</b> Presente, Retardo, Ausencia.'))
story.append(Spacer(1, 8))

# 3.4 Reportes
story.append(Paragraph('<b>3.4 Reportes</b>', H2_STYLE))
story.append(Paragraph(
    'El modulo de reportes permite generar informes detallados para analisis y cumplimiento normativo:',
    BODY_STYLE
))
story.append(Paragraph('<b>Tipos de reporte:</b>', H3_STYLE))
story.append(bullet('<b>Diario:</b> Resumen de asistencia del dia actual o fecha seleccionada.'))
story.append(bullet('<b>Horas extra:</b> Calculo de horas trabajadas adicionales a la jornada ordinaria, conforme a la Ley Federal del Trabajo.'))
story.append(bullet('<b>Ausencias:</b> Listado de empleados ausentes en un periodo determinado.'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>Filtros disponibles:</b>', H3_STYLE))
story.append(bullet('Por sucursal (Matriz, Sucursal 1, 2, 3)'))
story.append(bullet('Por rango de fechas'))
story.append(bullet('Por empleado'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>Formatos de exportacion:</b>', H3_STYLE))
story.append(bullet('<b>CSV:</b> Formato de valores separados por comas, compatible con cualquier herramienta de hojas de calculo.'))
story.append(bullet('<b>Excel:</b> Formato nativo de Microsoft Excel (.xlsx), con formato y estilos.'))
story.append(bullet('<b>Impresion:</b> Vista optimizada para impresion directa desde el navegador.'))

# 3.5 Auditoria
story.append(Paragraph('<b>3.5 Auditoria</b>', H2_STYLE))
story.append(Paragraph(
    'La seccion de auditoria muestra un registro inmutable de todas las acciones realizadas en el sistema:',
    BODY_STYLE
))
story.append(bullet('Inicio y cierre de sesion de usuarios'))
story.append(bullet('Creacion, modificacion y desactivacion de empleados'))
story.append(bullet('Registros de entrada y salida de asistencia'))
story.append(bullet('Generacion de codigos QR'))
story.append(bullet('Exportacion de reportes'))
story.append(Spacer(1, 6))
story.append(Paragraph(
    'Cada entrada de auditoria incluye: fecha y hora exacta, usuario que realizo la accion, '
    'tipo de accion y descripcion detallada. Los registros de auditoria no pueden ser modificados ni eliminados, '
    'garantizando la trazabilidad completa del sistema.',
    BODY_STYLE
))

# 3.6 Terminal QR
story.append(Paragraph('<b>3.6 Terminal QR</b>', H2_STYLE))
story.append(Paragraph(
    'La terminal QR es una funcionalidad disenada para ser mostrada en una pantalla o tablet en la '
    'entrada del lugar de trabajo. Genera un <b>codigo QR dinamico</b> que se renueva automaticamente cada 5 minutos.',
    BODY_STYLE
))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>Como funciona:</b>', H3_STYLE))
story.append(bullet('El administrador accede a la seccion "Terminal QR" desde el panel.'))
story.append(bullet('Se genera un codigo QR unico que contiene un token firmado criptograficamente.'))
story.append(bullet('El codigo se renueva cada 5 minutos automaticamente, mostrando el tiempo restante.'))
story.append(bullet('Los empleados escanean el codigo con su dispositivo para registrar su entrada o salida.'))
story.append(bullet('Cada token QR es de un solo uso y tiene fecha de expiracion, evitando suplantacion de identidad.'))
story.append(Spacer(1, 8))
story.append(Paragraph(
    'El sistema de QR dinamico utiliza firmas HMAC para garantizar la autenticidad de cada token. '
    'El formato del token es: NOM037:&lt;hex&gt;:&lt;timestamp&gt;:&lt;hmac_signature&gt;.',
    CALLOUT_STYLE
))

# ══════════════════════════════════════════════════════════════════
# 4. PANEL DEL EMPLEADO
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('4. Panel del Empleado'))
story.append(Paragraph(
    'El panel del empleado ofrece una interfaz simplificada para que los trabajadores registren '
    'su asistencia y consulten su informacion personal. Se accede con credenciales de rol EMPLOYEE.',
    BODY_STYLE
))

# 4.1 Registrar entrada/salida
story.append(Paragraph('<b>4.1 Registrar Entrada y Salida</b>', H2_STYLE))
story.append(Paragraph(
    'El proceso de registro de asistencia es obligatorio y requiere geolocalizacion GPS:',
    BODY_STYLE
))
story.append(Paragraph('<b>Pasos para registrar entrada:</b>', H3_STYLE))
story.append(bullet('1. Inicie sesion en el sistema con sus credenciales.'))
story.append(bullet('2. En el panel principal, haga clic en "Registrar Entrada".'))
story.append(bullet('3. El sistema solicitara acceso a su ubicacion GPS (obligatorio).'))
story.append(bullet('4. Seleccione el metodo de autenticacion: contrasena o escaneo de QR.'))
story.append(bullet('5. Confirme el registro. El sistema almacenara la fecha, hora y ubicacion.'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>Pasos para registrar salida:</b>', H3_STYLE))
story.append(bullet('1. En el panel principal, haga clic en "Registrar Salida".'))
story.append(bullet('2. El sistema verificara su ubicacion GPS actual.'))
story.append(bullet('3. Confirme el registro de salida.'))
story.append(Spacer(1, 8))
story.append(Paragraph(
    '<b>Nota importante:</b> La geolocalizacion es obligatoria para cada registro de asistencia, '
    'de acuerdo con los requisitos de la NOM-037-STPS-2023. Si el empleado no permite el acceso a su ubicacion, '
    'el registro no podra completarse.',
    CALLOUT_STYLE
))

# 4.2 Historial
story.append(Paragraph('<b>4.2 Historial de Asistencia</b>', H2_STYLE))
story.append(Paragraph(
    'El historial personal permite al empleado consultar sus registros de asistencia previos, '
    'incluyendo:',
    BODY_STYLE
))
story.append(bullet('Fecha y hora de cada entrada y salida registrada.'))
story.append(bullet('Ubicacion GPS al momento del registro.'))
story.append(bullet('Estado de cada registro (Presente, Retardo).'))
story.append(bullet('Calculo de horas trabajadas por dia.'))
story.append(Spacer(1, 6))
story.append(Paragraph(
    'El empleado puede filtrar su historial por rango de fechas para consultar periodos especificos.',
    BODY_STYLE
))

# 4.3 Mi QR
story.append(Paragraph('<b>4.3 Mi Codigo QR</b>', H2_STYLE))
story.append(Paragraph(
    'Cada empleado tiene asignado un codigo QR personal que sirve como metodo de autenticacion. '
    'Desde esta seccion, el empleado puede:',
    BODY_STYLE
))
story.append(bullet('Visualizar su codigo QR personal.'))
story.append(bullet('Descargar el codigo en formato imagen para uso offline.'))
story.append(bullet('Presentar el codigo en pantalla para ser escaneado por la terminal QR.'))
story.append(Spacer(1, 6))
story.append(Paragraph(
    'El codigo QR personal es unico e intransferible. En caso de comprometerse, '
    'puede ser regenerado por el administrador desde el panel de empleados.',
    BODY_STYLE
))

# ══════════════════════════════════════════════════════════════════
# 5. SISTEMA DE AUTENTICACION DUAL
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('5. Sistema de Autenticacion Dual'))
story.append(Paragraph(
    'El sistema implementa un mecanismo de autenticacion dual que combina dos metodos independientes '
    'para verificar la identidad del trabajador al registrar su asistencia. Este enfoque fortalece '
    'la seguridad y cumple con las mejores practicas de control de acceso.',
    BODY_STYLE
))

# 5.1 QR Dinamico
story.append(Paragraph('<b>5.1 Codigo QR Dinamico</b>', H2_STYLE))
story.append(Paragraph(
    'El codigo QR dinamico es generado por la terminal del administrador y se renueva cada 5 minutos. '
    'Su funcionamiento es el siguiente:',
    BODY_STYLE
))
story.append(bullet('El administrador accede a la seccion "Terminal QR" desde el panel de administracion.'))
story.append(bullet('Se genera un codigo QR que contiene un token criptograficamente firmado.'))
story.append(bullet('El token incluye una marca de tiempo y una firma HMAC que garantiza su autenticidad.'))
story.append(bullet('El empleado escanea el codigo con su dispositivo movil o lo ingresa manualmente.'))
story.append(bullet('El sistema valida la firma, la expiracion y registra la asistencia.'))
story.append(Spacer(1, 8))

story.append(Spacer(1, 10))
auth_table = make_table(
    ['Caracteristica', 'QR Dinamico', 'Contrasena'],
    [
        ['Generacion', 'Automatica cada 5 min', 'Definida por el empleado'],
        ['Validez', '5 minutos desde generacion', 'Permanente hasta cambio'],
        ['Seguridad', 'Token firmado HMAC', 'Cifrado en almacenamiento'],
        ['Uso', 'Escaneo en terminal', 'Ingreso manual'],
        ['Prevencion de suplantacion', 'Alta (token expira)', 'Media (depende del usuario)'],
    ],
    col_widths=[130, 160, 160]
)
story.append(auth_table)
story.append(Paragraph('Tabla 4. Comparacion de metodos de autenticacion', CAPTION_STYLE))

# 5.2 Contrasena
story.append(Paragraph('<b>5.2 Contrasena Personal</b>', H2_STYLE))
story.append(Paragraph(
    'La contrasena personal es el metodo de autenticacion tradicional. El empleado ingresa su correo '
    'electronico y contrasena en el formulario de inicio de sesion o en el momento de registrar su asistencia. '
    'Las contrasenas se almacenan de forma segura mediante cifrado hash y no son accesibles ni por los '
    'administradores del sistema.',
    BODY_STYLE
))
story.append(Spacer(1, 6))
story.append(Paragraph(
    'Se recomienda a los empleados utilizar contrasenas de al menos 8 caracteres, incluyendo mayusculas, '
    'minusculas, numeros y caracteres especiales.',
    BODY_STYLE
))

# ══════════════════════════════════════════════════════════════════
# 6. GEOLOCALIZACION
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('6. Geolocalizacion'))
story.append(Paragraph(
    'La geolocalizacion es un componente obligatorio del sistema de control de asistencia, '
    'requerido expresamente por la <b>NOM-037-STPS-2023</b> para verificar que el trabajador '
    'se encuentra en el lugar de trabajo al momento de registrar su asistencia.',
    BODY_STYLE
))
story.append(Spacer(1, 8))
story.append(Paragraph('<b>6.1 Como funciona</b>', H2_STYLE))
story.append(bullet('Al momento de registrar entrada o salida, el sistema solicita acceso a la ubicacion GPS del dispositivo.'))
story.append(bullet('Se capturan las coordenadas de latitud y longitud con la mayor precision disponible.'))
story.append(bullet('Las coordenadas se almacenan junto con el registro de asistencia y son visibles en el historial.'))
story.append(bullet('El administrador puede consultar la ubicacion de cada registro desde el panel de asistencias.'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>6.2 Por que es necesaria</b>', H2_STYLE))
story.append(Paragraph(
    'La NOM-037-STPS-2023 establece que el patron debe verificar que la persona trabajadora '
    'se encuentra en el lugar de trabajo durante su jornada laboral cuando realiza teletrabajo. '
    'La geolocalizacion GPS proporciona evidencia objetiva y verificable del cumplimiento de este requisito, '
    'protegiendo tanto al trabajador como al empleador.',
    BODY_STYLE
))
story.append(Spacer(1, 6))
story.append(Paragraph(
    '<b>Requisito normativo:</b> El Articulo 6 de la NOM-037 establece que el patron debera contar '
    'con un mecanismo para verificar que la persona trabajadora se encuentra en el lugar de trabajo. '
    'La geolocalizacion GPS cumple esta funcion de manera automatica y transparente.',
    CALLOUT_STYLE
))

# ══════════════════════════════════════════════════════════════════
# 7. CALCULO DE HORAS EXTRA
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('7. Calculo de Horas Extra'))
story.append(Paragraph(
    'El sistema calcula automaticamente las horas extra conforme a lo establecido en la '
    '<b>Ley Federal del Trabajo (LFT)</b> y los horarios configurados para cada empleado.',
    BODY_STYLE
))
story.append(Spacer(1, 8))
story.append(Paragraph('<b>7.1 Base de calculo</b>', H2_STYLE))

story.append(Spacer(1, 10))
overtime_table = make_table(
    ['Parametro', 'Valor', 'Referencia'],
    [
        ['Jornada ordinaria', '8 horas diarias', 'Art. 61 LFT'],
        ['Horas extra', 'Tiempo excedente despues de 8 hrs', 'Art. 66 LFT'],
        ['Pago de horas extra', 'Doble del salario por hora', 'Art. 67 LFT'],
        ['Tolerancia', '10 minutos (configurable)', 'Configuracion del sistema'],
        ['Horario sabado', '09:00 - 14:00 (5 hrs)', 'Horario predeterminado'],
        ['Maximo de horas extra', '3 horas diarias / 9 semanales', 'Art. 66 LFT'],
    ],
    col_widths=[130, 170, 130]
)
story.append(overtime_table)
story.append(Paragraph('Tabla 5. Parametros de calculo de horas extra', CAPTION_STYLE))

story.append(Spacer(1, 8))
story.append(Paragraph('<b>7.2 Ejemplo de calculo</b>', H2_STYLE))
story.append(Paragraph(
    'Para un empleado con horario de 09:00 a 18:00 (lunes a viernes):',
    BODY_STYLE
))
story.append(bullet('Si registra salida a las 19:30, se contabilizan 1.5 horas extra.'))
story.append(bullet('El sistema descuenta automaticamente la tolerancia de 10 minutos.'))
story.append(bullet('Las horas extra se calculan: (hora_salida - hora_salida_programada) - tolerancia.'))
story.append(Spacer(1, 6))
story.append(Paragraph(
    'El reporte de horas extra muestra el desglose detallado por empleado, dia y sucursal, '
    'facilitando el calculo de nomina y el cumplimiento de la legislacion laboral.',
    BODY_STYLE
))

# ══════════════════════════════════════════════════════════════════
# 8. REPORTES Y EXPORTACION
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('8. Reportes y Exportacion'))
story.append(Paragraph(
    'El modulo de reportes proporciona herramientas para generar informes detallados de asistencia, '
    'esenciales para el cumplimiento normativo y la gestion de recursos humanos.',
    BODY_STYLE
))
story.append(Spacer(1, 8))
story.append(Paragraph('<b>8.1 Tipos de reporte</b>', H2_STYLE))

story.append(Spacer(1, 10))
report_table = make_table(
    ['Tipo', 'Descripcion', 'Contenido'],
    [
        ['Diario', 'Resumen de asistencia del dia', 'Presentes, retardos, ausentes, horas trabajadas'],
        ['Horas extra', 'Calculo de horas excedentes', 'Horas extra por empleado, pago estimado'],
        ['Ausencias', 'Listado de faltas', 'Empleados ausentes, justificaciones, patrones'],
    ],
    col_widths=[100, 170, 190]
)
story.append(report_table)
story.append(Paragraph('Tabla 6. Tipos de reporte disponibles', CAPTION_STYLE))

story.append(Spacer(1, 8))
story.append(Paragraph('<b>8.2 Formatos de exportacion</b>', H2_STYLE))
story.append(bullet('<b>CSV:</b> Archivo de texto con valores separados por comas. Compatible con cualquier programa de hojas de calculo. Incluye prefijo BOM UTF-8 para correcta visualizacion de caracteres especiales.'))
story.append(bullet('<b>Excel (.xlsx):</b> Formato nativo de Microsoft Excel con formato profesional, encabezados estilizados y columnas ajustadas automaticamente.'))
story.append(bullet('<b>Impresion:</b> Vista optimizada para impresion con estilos de pagina adaptados para papel tamano carta u oficio.'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>8.3 Filtros disponibles</b>', H2_STYLE))
story.append(bullet('<b>Por sucursal:</b> Matriz, Sucursal 1, Sucursal 2, Sucursal 3, o todas.'))
story.append(bullet('<b>Por periodo:</b> Seleccion de fecha inicial y fecha final.'))
story.append(bullet('<b>Por empleado:</b> Busqueda individual por nombre o numero de empleado.'))

# ══════════════════════════════════════════════════════════════════
# 9. AUDITORIA Y TRAZABILIDAD
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('9. Auditoria y Trazabilidad'))
story.append(Paragraph(
    'El sistema mantiene un registro de auditoria completo e inmutable de todas las operaciones '
    'realizadas. Este mecanismo es fundamental para garantizar la transparencia y el cumplimiento '
    'de los requisitos de la NOM-037-STPS-2023.',
    BODY_STYLE
))
story.append(Spacer(1, 8))
story.append(Paragraph('<b>9.1 Acciones registradas</b>', H2_STYLE))
story.append(Paragraph(
    'Toda accion dentro del sistema genera automaticamente un registro de auditoria que incluye:',
    BODY_STYLE
))
story.append(bullet('<b>Fecha y hora exacta:</b> Timestamp preciso de cuando ocurrio la accion.'))
story.append(bullet('<b>Usuario:</b> Identificacion del usuario que realizo la accion.'))
story.append(bullet('<b>Tipo de accion:</b> Categoria de la operacion (LOGIN, LOGOUT, CHECK_IN, CHECK_OUT, CREATE, UPDATE, DELETE, EXPORT).'))
story.append(bullet('<b>Descripcion detallada:</b> Informacion completa sobre la accion realizada.'))
story.append(Spacer(1, 6))
story.append(Paragraph('<b>9.2 Inmutabilidad de los registros</b>', H2_STYLE))
story.append(Paragraph(
    'Los registros de auditoria son inmutables por diseno. Una vez creados, no pueden ser modificados '
    'ni eliminados por ningun usuario, incluyendo administradores. Esta caracteristica garantiza que:',
    BODY_STYLE
))
story.append(bullet('La pista de auditoria es completa y confiable.'))
story.append(bullet('No es posible ocultar o alterar acciones realizadas en el sistema.'))
story.append(bullet('Se cumple con el requisito de trazabilidad establecido por la NOM-037.'))
story.append(bullet('Los registros pueden ser utilizados como evidencia ante auditorias laborales.'))

# ══════════════════════════════════════════════════════════════════
# 10. RETENCION DE DATOS
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('10. Retencion de Datos'))
story.append(Paragraph(
    'La NOM-037-STPS-2023 establece que los registros de asistencia y los documentos relacionados '
    'deben conservarse durante un periodo minimo de <b>5 anos</b>. El sistema cumple con este requisito '
    'mediante las siguientes medidas:',
    BODY_STYLE
))
story.append(Spacer(1, 8))
story.append(bullet('<b>Almacenamiento persistente:</b> Todos los registros se almacenan en una base de datos con respaldo automatico.'))
story.append(bullet('<b>Politica de retencion:</b> Los datos se conservan por un minimo de 5 anos desde su generacion.'))
story.append(bullet('<b>Inmutabilidad:</b> Los registros no pueden ser alterados ni eliminados durante el periodo de retencion.'))
story.append(bullet('<b>Accesibilidad:</b> Los datos historicos estan disponibles para consulta y generacion de reportes en cualquier momento.'))
story.append(bullet('<b>Exportacion:</b> Los registros pueden ser exportados para resguardo externo o presentacion ante autoridades.'))
story.append(Spacer(1, 8))

story.append(Spacer(1, 10))
retention_table = make_table(
    ['Tipo de Dato', 'Periodo de Retencion', 'Base Normativa'],
    [
        ['Registros de asistencia', '5 anos', 'NOM-037-STPS-2023'],
        ['Registros de auditoria', '5 anos', 'NOM-037-STPS-2023'],
        ['Datos de empleados', '5 anos posteriores al cese', 'LFT / NOM-037'],
        ['Geolocalizacion', '5 anos', 'NOM-037-STPS-2023'],
        ['Codigos QR generados', '5 anos', 'Buena practica'],
    ],
    col_widths=[150, 150, 160]
)
story.append(retention_table)
story.append(Paragraph('Tabla 7. Politica de retencion de datos', CAPTION_STYLE))

# ══════════════════════════════════════════════════════════════════
# 11. PREGUNTAS FRECUENTES
# ══════════════════════════════════════════════════════════════════
story.extend(add_major_section('11. Preguntas Frecuentes'))

faqs = [
    ('Que es la NOM-037-STPS-2023?',
     'Es la Norma Oficial Mexicana que establece las condiciones de seguridad y salud en el trabajo '
     'para las personas trabajadoras que laboran bajo la modalidad de teletrabajo. Obliga a los patrones '
     'a llevar un registro de asistencia verificable.'),
    ('Es obligatorio el uso de GPS?',
     'Si. La geolocalizacion es un requisito de la NOM-037 para verificar que el trabajador se encuentra '
     'en el lugar de trabajo. Sin GPS, no es posible registrar la asistencia en el sistema.'),
    ('Que pasa si olvido registrar mi entrada o salida?',
     'Debe comunicarse con su administrador para que se registre manualmente la asistencia. '
     'Esta accion quedara registrada en la auditoria del sistema.'),
    ('Con que frecuencia se renueva el QR dinamico?',
     'El codigo QR de la terminal se renueva automaticamente cada 5 minutos. Si un empleado escanea '
     'un QR expirado, el sistema rechazara el registro y solicitara un nuevo escaneo.'),
    ('Quien puede ver mi ubicacion GPS?',
     'Solo los administradores del sistema pueden consultar la ubicacion asociada a cada registro de '
     'asistencia. La informacion se utiliza exclusivamente para cumplimiento normativo.'),
    ('Como se calculan las horas extra?',
     'Las horas extra se calculan automaticamente restando la hora de salida programada de la hora de '
     'salida real, menos la tolerancia configurada (10 minutos por defecto). El pago se calcula al doble '
     'del salario ordinario conforme a la LFT.'),
    ('Puedo cambiar mi contrasena?',
     'Actualmente, el cambio de contrasena debe ser solicitado al administrador del sistema. '
     'Se recomienda cambiar la contrasena periodicamente por seguridad.'),
    ('Los registros de asistencia pueden ser modificados?',
     'No. Los registros de asistencia son inmutables una vez creados. Esto garantiza la integridad '
     'de los datos y el cumplimiento de los requisitos normativos de la NOM-037.'),
    ('Por cuanto tiempo se conservan mis datos?',
     'Conforme a la NOM-037-STPS-2023, los registros de asistencia y auditoria se conservan '
     'por un periodo minimo de 5 anos.'),
    ('El sistema funciona sin conexion a internet?',
     'No. El sistema requiere conexion a internet para funcionar, ya que los registros se almacenan '
     'en un servidor centralizado y la validacion de QR requiere comunicacion con el servidor.'),
]

for i, (q, a) in enumerate(faqs, 1):
    story.append(Paragraph('<b>Pregunta %d: %s</b>' % (i, q), H3_STYLE))
    story.append(Paragraph(a, BODY_INDENT))
    story.append(Spacer(1, 6))

# ── Build the document ──
doc.multiBuild(story)
print(f"Body PDF generated: {OUTPUT_PATH}")
