#!/bin/bash
# Restart script for Next.js dev server
while true; do
  cd /home/z/my-project
  echo "$(date): Starting Next.js dev server..." >> /home/z/my-project/server-restart.log
  node node_modules/.bin/next dev -p 3000 >> /home/z/my-project/dev.log 2>&1
  EXIT_CODE=$?
  echo "$(date): Server exited with code $EXIT_CODE" >> /home/z/my-project/server-restart.log
  sleep 2
done
