-- Migration: Add sucursal support to attendance_records and create sucursales table
-- Date: 2024-01-01
-- Description: Adds sucursal column to attendance_records, creates sucursales lookup table,
--              seeds default sucursales, and adds index for performance.

-- 1. Add sucursal column to attendance_records
ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS sucursal TEXT NOT NULL DEFAULT 'Matriz';

-- 2. Create sucursales table
CREATE TABLE IF NOT EXISTS sucursales (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name TEXT UNIQUE NOT NULL,
  address TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 3. Enable RLS on sucursales
ALTER TABLE sucursales ENABLE ROW LEVEL SECURITY;

-- 4. Add permissive policy on sucursales
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'sucursales' AND policyname = 'Allow all on sucursales'
  ) THEN
    CREATE POLICY "Allow all on sucursales" ON sucursales FOR ALL USING (true) WITH CHECK (true);
  END IF;
END $$;

-- 5. Add trigger for updated_at on sucursales
DROP TRIGGER IF EXISTS set_sucursales_updated_at ON sucursales;
CREATE TRIGGER set_sucursales_updated_at BEFORE UPDATE ON sucursales FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- 6. Insert default sucursal (Matriz)
INSERT INTO sucursales (id, name, address, is_active, created_at, updated_at)
VALUES ('suc-matriz', 'Matriz', 'Oficina Principal', true, now(), now())
ON CONFLICT (name) DO NOTHING;

-- 7. Add index on attendance_records(sucursal) for filtering performance
CREATE INDEX IF NOT EXISTS idx_attendance_records_sucursal ON attendance_records(sucursal);
