#!/bin/bash
# Watchdog to keep Next.js dev server running
while true; do
  if ! ss -tlnp | grep -q ':3000'; then
    echo "$(date): Starting Next.js..." >> /home/z/my-project/watchdog.log
    cd /home/z/my-project
    node node_modules/.bin/next dev -p 3000 >> /home/z/my-project/dev.log 2>&1 &
    sleep 5
  fi
  sleep 5
done
