-- Migration: Add inconsistency feature columns to attendance_records
-- Description: Adds columns for auto-close, justification, and error jornada features
-- Required for NOM-037 compliance

-- Add auto_closed column (Salida Omitida flag)
ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS auto_closed BOOLEAN NOT NULL DEFAULT false;

-- Add needs_justification column
ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS needs_justification BOOLEAN NOT NULL DEFAULT false;

-- Add justification text column
ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS justification TEXT;

-- Add estimated check-in time (HH:mm format, for ERROR_JORNADA records)
ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS estimated_check_in_time TEXT;

-- Add estimated check-out time (HH:mm format, for SALIDA_OMITIDA records)
ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS estimated_check_out_time TEXT;

-- Add justification submission timestamp
ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS justification_submitted_at TEXT;

-- Add index for needs_justification for faster queries
CREATE INDEX IF NOT EXISTS idx_attendance_needs_justification ON attendance_records(needs_justification) WHERE needs_justification = true;
